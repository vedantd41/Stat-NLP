The directory "PA2_code" contains the starter code.
Feel free to ignore the starter code and implement from scratch.
However, you should use the base settings for the hyperparameters, as specified in main.py.

The directory "PA2_code/speechesdataset" contains the data to be used for this assignment.
